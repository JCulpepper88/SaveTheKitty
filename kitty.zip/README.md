Save the Kitty
==============

Get the weapon and kill the monster before it gets to the kitty! The monster moves in a random direction every half second.

Each of the levels is an array of characters parsed by the program. After completing all the levels, you return to level 1, but the monster doubles in speed.

## Issues

* Sometimes the monster move function can't seem to find the level map.
* I eventually plan to connect this to a database to keep track of high scores.
* I might make the monster smarter.